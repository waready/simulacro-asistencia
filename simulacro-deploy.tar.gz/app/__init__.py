"""Simulacro API package."""
